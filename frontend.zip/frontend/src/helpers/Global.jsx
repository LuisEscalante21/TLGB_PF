export const Global = {
    url: "http://localhost:4000/api/"
};